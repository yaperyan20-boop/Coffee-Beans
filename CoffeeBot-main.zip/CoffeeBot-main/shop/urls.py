from django.urls import path

from . import views

app_name = 'shop'

urlpatterns = [
    path('', views.shop_home, name='home'),
    path('api/chat/', views.chat_completion, name='chat_completion'),
]

