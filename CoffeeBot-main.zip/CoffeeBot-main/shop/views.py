from dataclasses import dataclass
import json

import requests
from django.conf import settings
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST

OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions'
DEFAULT_MODEL = 'openai/gpt-4o-mini'


@dataclass
class CoffeeBean:
    name: str
    origin: str
    tasting_notes: str
    price_php: int
    stock_status: str


COFFEE_BEANS = [
    CoffeeBean(
        name='Aurora Espresso',
        origin='Blend: Ethiopia & Colombia',
        tasting_notes='Blackberry compote, cacao nibs, velvety body',
        price_php=1045,
        stock_status='In Stock',
    ),
    CoffeeBean(
        name='Cascade Bloom',
        origin='Single Origin: Guatemala Huehuetenango',
        tasting_notes='Honeycrisp apple, nougat, lime zest finish',
        price_php=1190,
        stock_status='Low Stock',
    ),
    CoffeeBean(
        name='Midnight Drift Decaf',
        origin='Swiss Water Process, Peru',
        tasting_notes='Dark chocolate, praline, gentle plum sweetness',
        price_php=1105,
        stock_status='In Stock',
    ),
]


def shop_home(request):
    return render(
        request,
        'shop/index.html',
        {
            'coffee_beans': COFFEE_BEANS,
        },
    )


@csrf_exempt
@require_POST
def chat_completion(request):
    try:
        payload = json.loads(request.body.decode('utf-8'))
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON payload.'}, status=400)

    user_message = payload.get('message', '').strip()
    history = payload.get('history', [])

    if not user_message:
        return JsonResponse({'error': 'Message cannot be empty.'}, status=400)

    api_key = settings.OPENROUTER_API_KEY
    if not api_key:
        return JsonResponse(
            {'error': 'OpenRouter API key is not configured.'},
            status=500,
        )

    openrouter_messages = history + [
        {
            'role': 'user',
            'content': user_message,
        }
    ]

    request_body = {
        'model': DEFAULT_MODEL,
        'messages': openrouter_messages,
        'max_tokens': 350,
        'temperature': 0.8,
    }

    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json',
        'HTTP-Referer': 'http://localhost:8000',
        'X-Title': 'CoffeeBot Shop',
    }

    try:
        response = requests.post(
            OPENROUTER_API_URL,
            headers=headers,
            json=request_body,
            timeout=30,
        )
        response.raise_for_status()
        completion = response.json()
        reply = completion['choices'][0]['message']['content']
    except requests.RequestException as exc:
        return JsonResponse(
            {'error': 'Unable to reach the AI service.', 'details': str(exc)},
            status=502,
        )
    except (KeyError, IndexError):
        return JsonResponse(
            {'error': 'Unexpected response from AI service.'},
            status=502,
        )

    return JsonResponse({'reply': reply})
